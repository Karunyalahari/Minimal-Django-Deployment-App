from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
import requests
from textblob import TextBlob

def home(request):
    return render(request, 'dealership/home.html')

def about(request):
    return render(request, 'dealership/about.html')

def contact(request):
    return render(request, 'dealership/contact.html')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'dealership/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'dealership/signup.html', {'form': form})

@login_required
def add_review(request):
    if request.method == 'POST':
        review_text = request.POST.get('review')
        rating = int(request.POST.get('rating'))
        dealer_id = request.POST.get('dealer_id')
        username = request.user.username

        sentiment_score = TextBlob(review_text).sentiment.polarity
        sentiment = 'positive' if sentiment_score > 0 else 'negative' if sentiment_score < 0 else 'neutral'

        payload = {
            "dealerId": dealer_id,
            "user": username,
            "review": review_text,
            "rating": rating,
            "sentiment": sentiment
        }

        response = requests.post("https://your-express-api.onrender.com/api/dealers/reviews", json=payload)

        if response.status_code == 200:
            return redirect('dealer_details', id=dealer_id)
        else:
            return render(request, 'dealership/add_review.html', {'error': 'Failed to post review'})
    return render(request, 'dealership/add_review.html')

def dealer_details(request, id):
    return render(request, 'dealership/dealer_details.html', {'dealer_id': id})