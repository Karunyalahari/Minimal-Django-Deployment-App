const express = require('express');
const router = express.Router();
const Dealer = require('../models/Dealer');
const Review = require('../models/Review');

router.get('/', async (req, res) => {
    const dealers = await Dealer.find();
    res.json(dealers);
});

router.get('/state/:state', async (req, res) => {
    const dealers = await Dealer.find({ state: req.params.state });
    res.json(dealers);
});

router.get('/:id', async (req, res) => {
    const dealer = await Dealer.findById(req.params.id);
    res.json(dealer);
});

router.get('/:id/reviews', async (req, res) => {
    const reviews = await Review.find({ dealerId: req.params.id });
    res.json(reviews);
});

router.post('/reviews', async (req, res) => {
    try {
        const newReview = new Review(req.body);
        await newReview.save();
        res.status(200).json({ message: "Review added" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;