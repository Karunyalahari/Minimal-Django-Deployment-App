const mongoose = require('mongoose');

const ReviewSchema = new mongoose.Schema({
    dealerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Dealer' },
    user: String,
    review: String,
    rating: Number,
    sentiment: String
});

module.exports = mongoose.model('Review', ReviewSchema);