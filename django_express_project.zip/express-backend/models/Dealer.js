const mongoose = require('mongoose');

const DealerSchema = new mongoose.Schema({
    name: String,
    city: String,
    state: String,
    carsAvailable: [String]
});

module.exports = mongoose.model('Dealer', DealerSchema);